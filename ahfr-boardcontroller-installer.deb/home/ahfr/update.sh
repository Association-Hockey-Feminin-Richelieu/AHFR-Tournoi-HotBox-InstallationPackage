#!/bin/bash

# Configuration
IMAGE_NAME="quay.io/hockeyfemininrichelieu/ahfr-tournoi-hotbox-boardcontroller:stable-latest"
CHECK_HOST="8.8.8.8"
TIMEOUT=5

echo "Checking internet connectivity..."

# Check if we can ping the host within the timeout
# -c 1: send one packet
# -W 5: wait 5 seconds for a response
if ping -c 1 -W $TIMEOUT $CHECK_HOST > /dev/null 2>&1; then
    echo "✅ Internet is up. Proceeding to pull $IMAGE_NAME..."
    
    # Attempt the pull
    if sudo podman pull "$IMAGE_NAME"; then
        
        echo "Successfully pulled $IMAGE_NAME"

        echo "Tagging stable image as ahfr-tournoi-hotbox-boardcontroller:running"
        sudo podman tag $IMAGE_NAME ahfr-tournoi-hotbox-boardcontroller:running

        echo "Reloading and restarting the container now ..."
        
        sudo systemctl restart ahfr-boardcontroller \
        && ~/scripts/refresh

    else
        echo "❌ Error[PULL_ERR]: Podman pull failed (Check if the image name is correct)."
        exit 1
    fi
else
    echo "❌ Error[NO_INET]: No internet connectivity detected. Aborting."
    exit 1
fi
